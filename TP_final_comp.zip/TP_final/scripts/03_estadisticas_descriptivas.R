#-------------------------ESTADISTICAS DESCRIPTIVAS------------------------------->


#------------BASE 1: Monto de préstamos hipotecarios en Unidades de Valor Adquisitivo

#Monto de préstamos hipotecarios en Unidades de Valor Adquisitivo

#promedio del monto operado 
mean_monto <- mean(as.numeric(datos_combinados$monto_usd), na.rm = TRUE)
mean_monto

#desviacion estandar del monto operado 
sd_monto <- sd(as.numeric(datos_combinados$monto_usd), na.rm = TRUE)
sd_monto

#mediana del monto operado
median_monto <- median(as.numeric(datos_combinados$monto_usd), na.rm = TRUE)
median_monto

#promedio de la variacion mensual
mean_var_mensual <- mean(as.numeric(datos_combinados$var_mensual), na.rm = TRUE)
mean_var_mensual

#variación anual maxima
var_max <- datos_combinados %>%
  filter(!is.na(var_anual)) %>%
  slice_max(var_anual, n = 1)
var_max


#rango del monto operado
range_monto <- max(as.numeric(datos_combinados$monto_usd), na.rm = TRUE) -
  min(as.numeric(datos_prestamos$monto_operado), na.rm = TRUE)
range_monto


#-----------------BASE 2------------------
# Precio promedio alquiler 
colnames(datos_alquiler_usd)

datos_alquiler_usd %>%
  summarise(
    precio_prom_usd_mean = mean(precio_prom_usd, na.rm = TRUE),
    precio_prom_usd_median = median(precio_prom_usd, na.rm = TRUE),
    precio_prom_usd_sd = sd(precio_prom_usd, na.rm = TRUE),
    precio_prom_usd_min = min(precio_prom_usd, na.rm = TRUE),
    precio_prom_usd_max = max(precio_prom_usd, na.rm = TRUE)
  )


datos_alquiler_usd %>%
  group_by(año) %>%
  summarise(
    promedio_usd = mean(precio_prom_usd, na.rm = TRUE),
    mediana_usd = median(precio_prom_usd, na.rm = TRUE),
    sd_usd = sd(precio_prom_usd, na.rm = TRUE),
    n = n()
  )


resumen_precio_barrio_anual <- datos_alquiler_usd %>%
  filter(!is.na(precio_prom_usd)) %>%
  group_by(barrio, año) %>%
  summarise(precio_prom_usd_anual = mean(precio_prom_usd, na.rm = TRUE), .groups = "drop")

#-----------------BASE 3------------------
# Precio de venta de departamentos

names(datos_precios_venta) <- c("barrio", "año", "trimestre", "precio_prom","ambientes","estado","comuna")

# Analisis de precio promedio

datos_precios_venta <- datos_precios_venta %>%
  filter(!is.na(precio_prom))
resumen <- datos_precios_venta %>%
  summarise(
    cantidad = n(),
    media = mean(precio_prom),
    mediana = median(precio_prom),
    minimo = min(precio_prom),
    maximo = max(precio_prom),
    desviacion_estandar = sd(precio_prom),
    rango = max(precio_prom) - min(precio_prom),
    coef_variacion = sd(precio_prom) / mean(precio_prom)
  )

print(resumen)

# Analisis por barrio 

estadisticas_por_barrio <- datos_precios_venta %>%
  group_by(barrio) %>%
  summarise(
    cantidad = n(),
    media = mean(precio_prom),
    mediana = median(precio_prom),
    minimo = min(precio_prom),
    maximo = max(precio_prom),
    desviacion = sd(precio_prom),
    rango = max(precio_prom) - min(precio_prom),
    coef_var = sd(precio_prom) / mean(precio_prom)
  ) %>%
  arrange(desc(media))  

print(estadisticas_por_barrio)

#-----------------BASE 4------------------
# Superficie total de departamentos en alquiler
names(datos_superficie)<- c("barrio", "año","mes","superficie","comuna")

summary(datos_superficie$superficie)

# 2. Estadísticas descriptivas por barrio
datos_superficie %>%
  group_by(barrio) %>%
  summarise(
    cantidad = n(),
    media = mean(superficie, na.rm = TRUE),
    mediana = median(superficie, na.rm = TRUE),
    sd = sd(superficie, na.rm = TRUE),
    minimo = min(superficie, na.rm = TRUE),
    maximo = max(superficie, na.rm = TRUE),
    q25 = quantile(superficie, 0.25, na.rm = TRUE),
    q75 = quantile(superficie, 0.75, na.rm = TRUE)
  )

# 3. Estadísticas descriptivas por año 

datos_superficie %>%
  group_by(año) %>%
  summarise(
    media = mean(superficie, na.rm = TRUE),
    sd = sd(superficie, na.rm = TRUE),
    minimo = min(superficie, na.rm = TRUE),
    maximo = max(superficie, na.rm = TRUE),
    cantidad = n()
  )


# cuantos m2 se comercializan más en promedio por comuna
superficie_promedio_comuna <- datos_superficie %>%
  group_by(comuna) %>%
  summarise(
    cantidad = n(),
    promedio_m2 = mean(superficie, na.rm = TRUE),
    mediana_m2 = median(superficie, na.rm = TRUE),
    sd_m2 = sd(superficie, na.rm = TRUE)
  ) %>%
  arrange(desc(promedio_m2))

print(superficie_promedio_comuna)


# promedio general de m2 de deptos en alquiler

resumen_general <- datos_superficie %>%
  summarise(
    cantidad = n(),
    promedio_m2 = mean(superficie, na.rm = TRUE),
    mediana_m2 = median(superficie, na.rm = TRUE),
    sd_m2 = sd(superficie, na.rm = TRUE),
    minimo = min(superficie, na.rm = TRUE),
    maximo = max(superficie, na.rm = TRUE),
    q25 = quantile(superficie, 0.25, na.rm = TRUE),
    q75 = quantile(superficie, 0.75, na.rm = TRUE)
  )
print(resumen_general)
#
