#------------------------MODELADO------------------------------->

#------------------------BASE 1------------------------
# RELACIÓN DE PRESTAMOS CON PRECIO DE VENTA - COMO COVARIAN O COMO FLUCTUAN CONJUNTAMENTE


#####

install.packages("scales")  # Solo si no lo tenés
library(scales)
monto_total_por_año <- datos_combinados %>%
  group_by(año) %>%
  summarise(monto_total_usd = sum(monto_usd, na.rm = TRUE))

ggplot(monto_total_por_año, aes(x = factor(año), y = monto_total_usd)) +
  geom_bar(stat = "identity", fill = "darkgreen") +
  scale_y_continuous(labels = label_number(scale = 1e-3, suffix = "k", accuracy = 0.1)) +
  labs(title = "Monto Total de Préstamos en USD por Año",
       x = "Año",
       y = "Monto Total (USD)") +
  theme_minimal()

#------------------------BASE 2------------------------
# RELACIÓN DE PRECIO PROMEDIO ALQUILER CON LA CANTIDAD DE M2 DE BASE 4 
# RELACIÓN DE PRECIO PROMEDIO ALQUILER CON RELACIÓN AL PRESTAMO UVA
# VER EN RELACION AL BARRIO EL PRECIO ALQUILER, Y VER CUAL VARIÓ MÁS ANUALMENTE 
# CUALES SON LOS MESES CON MAYORES AUMENTOS INDEPENDIENTEMENTE DEL AÑO
# CUAL FUE EL AÑO CON MAS AUMENTOS Y CUALES FUERON LOS PRIMERO 5 EN EXPLICARLO


#------------------------BASE 3------------------------
# PRECIO VENTA Y M2 POR AÑO
# PRECIO VENTA POR BARRIO  - CUALES SUBIERON MÁS, CUALES SON LOS MÁS CAROS, EN QUÉ AÑO HUBIERON MAYORES FLUCTUACIONES ANUALES


#---------- Grafico de barras: precio m2 por barrio 
library(ggplot2)

ggplot(estadisticas_por_barrio, aes(x = reorder(barrio, media), y = media)) +
  geom_col(fill = "#0072B2") +
  coord_flip() +  # para que los barrios se vean en vertical
  theme_minimal(base_size = 14) +
  labs(
    title = "Precio promedio por barrio",
    x = "Barrio",
    y = "Precio promedio (USD)"
  )

#---------- Boxplot: precio por barrio 
ggplot(datos_precios_venta, aes(x = reorder(barrio, precio_prom, FUN = median), y = precio_prom)) +
  geom_boxplot(fill = "#009E73") +
  coord_flip() +
  theme_minimal(base_size = 14) +
  labs(
    title = "Distribución de precios por barrio",
    x = "Barrio",
    y = "Precio del m2 en USD"
  )

#-------- grafico top 5 más caros
# Paso 1: Seleccionar los 6 barrios más caros
top_barrios_caros <- estadisticas_por_barrio %>%
  arrange(desc(media)) %>%
  slice_head(n = 8)

# Paso 2: Agregar la media al dataset original para mapear el color
datos_top_caros <- datos_precios_venta %>%
  filter(barrio %in% top_barrios_caros$barrio) %>%
  left_join(top_barrios_caros %>% select(barrio, media), by = "barrio") %>%
  mutate(
    # Ordenar los barrios de más caro (arriba) a más barato (abajo)
    barrio = factor(barrio, levels = rev(top_barrios_caros$barrio))
  )

# Paso 3: Boxplot con color variable según la media
ggplot(datos_top_caros, aes(x = barrio, y = precio_prom, fill = media)) +
  geom_boxplot() +
  coord_flip() +
  scale_fill_gradient(low = "#b7efc5", high = "#006400") +  # Verde claro a verde oscuro
  theme_minimal(base_size = 14) +
  labs(
    title = " Top 8 barrios más caros ",
    x = "Barrio",
    y = "Precio del m2 en USD",
    fill = "Precio promedio"
  )

#-------- grafico top 5 más baratos
# Paso 1: Seleccionar los 8 barrios más baratos
barrios_mas_baratos <- estadisticas_por_barrio %>%
  arrange(media) %>%
  slice_head(n = 8)

# Paso 2: Agregar la media al dataset original para mapear el color
datos_baratos <- datos_precios_venta %>%
  filter(barrio %in% barrios_mas_baratos$barrio) %>%
  left_join(barrios_mas_baratos %>% select(barrio, media), by = "barrio") %>%
  mutate(
    # Ordenar los barrios del menos barato (arriba) al más barato (abajo)
    barrio = factor(barrio, levels = barrios_mas_baratos$barrio)
  )

# Paso 3: Boxplot con color variable según la media
ggplot(datos_baratos, aes(x = barrio, y = precio_prom, fill = media)) +
  geom_boxplot() +
  coord_flip() +
  scale_fill_gradient(low = "#cce5ff", high = "#004c99") +  # Azul claro a azul oscuro
  theme_minimal(base_size = 14) +
  labs(
    title = "Top 8 barrios más baratos",
    x = "Barrio",
    y = "Precio del m² en USD",
    fill = "Precio promedio"
  )

#------------------------BASE 4------------------------

#boxplot: superficie por barrio
ggplot(datos_superficie, aes(x = reorder(barrio, superficie, median, na.rm = TRUE), y = superficie)) +
  geom_boxplot(fill = "skyblue", color = "darkblue") +
  coord_flip() +
  labs(title = "Distribución de Superficie por Barrio",
       x = "Barrio",
       y = "Superficie (m2)") +
  theme_minimal()


#grafico de barras: superficie por barrio
datos_promedio <- datos_superficie %>%
  group_by(barrio) %>%
  summarise(media_superficie = mean(superficie, na.rm = TRUE)) %>%
  arrange(desc(media_superficie))

ggplot(datos_promedio, aes(x = reorder(barrio, media_superficie), y = media_superficie)) +
  geom_bar(stat = "identity", fill = "lightgreen") +
  coord_flip() +
  labs(title = "Superficie Promedio de Departamentos por Barrio",
       x = "Barrio",
       y = "Superficie Promedio (m2)") +
  theme_minimal()


# grafico de barras: superficie por año
datos_anuales <- datos_superficie %>%
  group_by(año) %>%
  summarise(superficie_total = sum(superficie, na.rm = TRUE))

ggplot(datos_anuales, aes(x = factor(año), y = superficie_total)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  labs(title = "Superficie Total en Alquiler por Año",
       x = "Año",
       y = "Superficie Total (m2)") +
  theme_minimal()

# grafico de lineas: superficie por año

datos_promedio_anual <- datos_superficie %>%
  group_by(año) %>%
  summarise(superficie_promedio = mean(superficie, na.rm = TRUE))

ggplot(datos_promedio_anual, aes(x = año, y = superficie_promedio)) +
  geom_line(color = "darkgreen", size = 1) +
  geom_point(color = "darkgreen", size = 2) +
  geom_text(aes(label = round(superficie_promedio, 1)),
            vjust = -0.7, size = 3.5, color = "black") +
  scale_x_continuous(
    breaks = seq(min(datos_promedio_anual$año), max(datos_promedio_anual$año), by = 1)
  ) +
  labs(title = "Superficie Promedio en Alquiler por Año",
       x = "Año",
       y = "Superficie Promedio (m2)") +
  theme_minimal()

#boxplot: sperficie por año

ggplot(datos_superficie, aes(x = factor(año), y = superficie)) +
  geom_boxplot(fill = "skyblue", color = "darkblue") +
  labs(title = "Distribución de Superficie en Alquiler por Año",
       x = "Año",
       y = "Superficie (m2)") +
  theme_minimal()
