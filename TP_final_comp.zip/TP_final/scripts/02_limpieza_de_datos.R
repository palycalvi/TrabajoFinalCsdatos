#-------------------------LIMPIEZA DE DATOS------------------------------->

#------------BASE 1: Monto de préstamos hipotecarios en Unidades de Valor Adquisitivo ------------------
names(datos_prestamos) <- c("año_mes", "monto_operado", "var_mensual", "var_anual")

datos_prestamos <- datos_prestamos %>%
  separate(col = año_mes, into = c("año", "mes"), sep = "-", convert = TRUE)


datos_prestamos <- datos_prestamos %>%
  mutate(
    mes = case_when(
      mes == 1  ~ "Ene",
      mes == 2  ~ "Feb",
      mes == 3  ~ "Mar",
      mes == 4  ~ "Abr",
      mes == 5  ~ "May",
      mes == 6  ~ "Jun",
      mes == 7  ~ "Jul",
      mes == 8  ~ "Ago",
      mes == 9  ~ "Sep",
      mes == 10 ~ "Oct",
      mes == 11 ~ "Nov",
      mes == 12 ~ "Dic"
    )
  )

datos_combinados <- datos_prestamos %>%
  left_join(preciousd, by = c("año", "mes")) %>%
  mutate(monto_usd = monto_operado / precio_usd)


#-----------------BASE 2: Precio promedio alquiler ------------------
names(datos_precios_alquiler) <- c("barrio", "año", "mes", "precio_prom","ambientes","comuna")

#corregimos NuÃ±ez por "Nuñez"
datos_precios_alquiler <- datos_precios_alquiler %>%
  mutate(barrio = ifelse(barrio == "NuÃ±ez", "Nuñez", barrio))

#le agregamos el precio en dolares, para poder hacerlo comparativo teniendo en cuenta el valor del dolar "blue" 
datos_alquiler_usd <- datos_precios_alquiler %>%
  left_join(preciousd, by = c("año", "mes")) %>%
  rename(precio_prom_usd = precio_usd)

datos_alquiler_usd <- datos_alquiler_usd %>%
  mutate(precio_prom_usd = precio_prom / precio_prom_usd)


#-----------------BASE 3:  Precio de venta de departamentos------------------
names(datos_precios_venta) <- c("barrio", "año", "trimestre", "precio_prom","ambientes","estado","comuna")

#corregimos NuÃ±ez por "Nuñez"
datos_precios_venta <- datos_precios_venta %>%
  mutate(barrio = ifelse(barrio == "NuÃ±ez", "Nuñez", barrio))

#-----------------BASE 4: Superficie total de departamentos en alquiler------------------
names(datos_superficie)<- c("barrio", "año","mes","superficie","comuna")

#corregimos NuÃ±ez por "Nuñez"
datos_superficie <- datos_superficie %>%
  mutate(barrio = ifelse(barrio == "NuÃ±ez", "Nuñez", barrio))
