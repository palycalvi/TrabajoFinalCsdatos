#-------------------------EXTRACCIÓN DE DATOS------------------------------->

library(stringr)
library(tidyr)
library(dplyr)
install.packages("readr")
library(readr)
ruta<-"C:/Users/paloc/OneDrive/Documentos/UBA/Ciencia de datos/TP_final"


#-----------------
# BASE 1 - Monto de préstamos hipotecarios en Unidades de Valor Adquisitivo 

datos_prestamos<- read.csv("C:/Users/paloc/OneDrive/Documentos/UBA/Ciencia de datos/TP_final/raw/montos-creditos-hipotecariosuva.csv",  fileEncoding = "latin1", sep = ";")

#-----------------
# BASE 2- Precio promedio alquiler 

##  Usamos base de datos de dolar 

datos_precios_alquiler <- read.csv("C:/Users/paloc/OneDrive/Documentos/UBA/Ciencia de datos/TP_final/raw/precio-alquiler-deptos.csv",  fileEncoding = "latin1", sep = ";")

precio_usd <- read.csv("C:/Users/paloc/OneDrive/Documentos/UBA/Ciencia de datos/TP_final/raw/promedio_dolar_mensual.csv",  fileEncoding = "latin1", sep = ";")
colnames(precio_usd)[1] <- "fecha_precio"   
preciousd <- precio_usd %>%
  separate(col = fecha_precio, into = c("año", "mes", "precio_usd"), sep = ",", convert = TRUE)

#-----------------
# BASE 3 - Precio de venta de departamentos

   datos_precios_venta <- read.csv("C:/Users/paloc/OneDrive/Documentos/UBA/Ciencia de datos/TP_final/raw/precio-venta-deptos.csv",  fileEncoding = "latin1", sep = ";")


# como está dividida en trimestres, calculamos el precio promedio del dolar por trimestre 

## base 2 de dolar dividida por trimestre:

precio_usd2 <- read.csv("C:/Users/paloc/OneDrive/Documentos/UBA/Ciencia de datos/TP_final/raw/preciodolarhist.csv",  fileEncoding = "latin1", sep = ";")
precio_usd2 <- precio_usd2 %>%
  rename(valor = 1) %>%  
  separate(valor, into = c("fecha_completa", "precio_usd"), sep = ",") %>%
  mutate(
    mes = stringr::str_sub(fecha_completa, 5, 7),
    año = stringr::str_sub(fecha_completa, -4),
    precio_usd = as.numeric(precio_usd)
  ) %>%
  group_by(año, mes) %>%
  summarise(promedio_precio_usd = mean(precio_usd, na.rm = TRUE)) %>%
  ungroup()

precio_usd2 <- precio_usd2 %>%
  mutate(
    trimestre = case_when(
      mes %in% c("Jan", "Feb", "Mar") ~ 1,
      mes %in% c("Apr", "May", "Jun") ~ 2,
      mes %in% c("Jul", "Aug", "Sep") ~ 3,
      mes %in% c("Oct", "Nov", "Dec") ~ 4,
      TRUE ~ NA_real_
    )
  )

precio_usd_trimestral <- precio_usd2 %>%
  group_by(año, trimestre) %>%
  summarise(promedio_trimestral = mean(promedio_precio_usd, na.rm = TRUE)) %>%
  arrange(año, trimestre)


precio_usd_trimestral <- precio_usd_trimestral %>%
  mutate(
    año = as.integer(año),
    trimestre = as.integer(trimestre)
  )

#-----------------
# BASE 4 - Superficie total de departamentos en alquiler

   datos_superficie <- read.csv("C:/Users/paloc/OneDrive/Documentos/UBA/Ciencia de datos/TP_final/raw/superficie-deptos.csv",  fileEncoding = "latin1", sep = ";")

#-----------------
# BASE 5 - Actividad inmobiliaria - venta

   datos_activ_inm<- read.csv("C:/Users/paloc/OneDrive/Documentos/UBA/Ciencia de datos/TP_final/raw/actas-notariales-compra-venta-inmuebles-hipotecas.csv",  fileEncoding = "latin1", sep = ";")




















